A few small bugfixes, and one rather important one from the previous release!

### Fixes

- Fix food items not cooking in heat devices (#2748)
- Fix lighting already lit devices instantly voiding fuel (#2746)
- Fix a config typo (#2745)